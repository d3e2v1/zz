import React from 'react'
import { Link } from 'react-router-dom';
import './albumhome.css'
import img1 from '../../assets/album.jpg'
import img2 from '../../assets/frame.png'

function Albumhome()
{
    return(
        <div>

<div ><img class="uk-align-center uk-hidden@s uk-hidden@m  imgg2"  src={img1}></img></div>
<div><img class="uk-align-center uk-visible@s imgg1 "  src={img1}></img></div>
<div><img class="uk-align-center uk-visible@s  imgg3 "  src={img2}></img></div>
<div><img class="uk-align-center uk-hidden@s uk-hidden@m imgg4 "  src={img2}></img></div>
<div class="a1"><span > Neelima & Matt Harris</span></div><br/>

<div class="a2"><span uk-icon=" "> VIEW PHOTOS<a href="" uk-icon="chevron-down"></a></span></div>

        </div>

        );
    }
     export default Albumhome;