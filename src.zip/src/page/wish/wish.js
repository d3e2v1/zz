import React from 'react'
import { Link } from 'react-router-dom';
import './wish.css'
import img3 from '../../assets/a1.png'
import img4 from '../../assets/f1.png'
function Wish()
{
    return(
        <div>
<div class="" style={{marginTop:"3%",margin:"4%"}}>
<a href="/" >
<button class="uk-button uk-button-default   btn2" style={{color:"#ef1372",borderColor:"#ef1372",borderRadius:"20px",textTransform:"initial",marginLeft:"8%"}} href="#">Back to invite</button>
</a>  
<p class="span111 ">Sreejith & Shalin</p><br/>
{/* <p class="span111 uk-hidden@s uk-hidden@m">Sreejith & Shalin</p><br/> */}

<div class="uk-card uk-align-center uk-width-1-1@s uk-width-1-2@l uk-width-1-2@m span12" >
    <span>Best wishes for the most beautiful bride❤️ Wishing Shalini 
        and Sreejith infinite years of togetherness filled with peace, good health 
        and joy! All cheers for the dream come true wedding! 🎉 Love you both dears 😘<br/>&nbsp;&nbsp;
        <svg style={{width:"2%",height:"3%",color:"#ef1372"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"><switch><g><path d="M16.143 18.594h-.1c-6.6-2.5-7.4-5.9-7.4-8.6 0-2.5 1.8-4.5 3.9-4.5 1.5 0 2.9.8 3.6 2.1.7-1.3 2.1-2.1 3.6-2.1 2.2 0 3.9 2 3.9 4.5 0 2.7-.8 6.1-7.4 8.6h-.1zm-3.5-12.5s-.1 0 0 0c-1.8 0-3.3 1.7-3.3 3.8 0 2.4.8 5.6 6.8 7.9 6.1-2.4 6.8-5.5 6.8-7.9 0-2.1-1.5-3.8-3.2-3.8-1.5 0-2.9 1-3.3 2.4 0 .1-.2.2-.3.2-.2 0-.3-.1-.3-.3-.4-1.3-1.7-2.3-3.2-2.3zM6.343 8.494h-5.7c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h5.7c.2 0 .3.2.3.3s-.1.3-.3.3zM6.343 12.394h-5.7c-.2 0-.3-.2-.3-.3 0-.2.2-.3.3-.3h5.7c.2 0 .3.2.3.3.1.1-.1.3-.3.3zM6.343 16.194h-2.5c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h2.5c.2 0 .3.2.3.3s-.1.3-.3.3z"></path></g></switch></svg>
        Pri</span>
</div>


<div class="uk-card uk-align-center uk-width-1-1@s uk-width-1-2@l uk-width-1-2@m span11" >
    <span>Heartfelt congratulations to you macha! Like today, may every other day of 
        your life be filled with love and compassion! Here's to a beautiful couple and 
        a lifetime of wonderful memories.<br/>&nbsp;&nbsp;
        
        <svg style={{width:"2%",height:"3%",color:"#ef1372"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"><switch><g><path d="M16.143 18.594h-.1c-6.6-2.5-7.4-5.9-7.4-8.6 0-2.5 1.8-4.5 3.9-4.5 1.5 0 2.9.8 3.6 2.1.7-1.3 2.1-2.1 3.6-2.1 2.2 0 3.9 2 3.9 4.5 0 2.7-.8 6.1-7.4 8.6h-.1zm-3.5-12.5s-.1 0 0 0c-1.8 0-3.3 1.7-3.3 3.8 0 2.4.8 5.6 6.8 7.9 6.1-2.4 6.8-5.5 6.8-7.9 0-2.1-1.5-3.8-3.2-3.8-1.5 0-2.9 1-3.3 2.4 0 .1-.2.2-.3.2-.2 0-.3-.1-.3-.3-.4-1.3-1.7-2.3-3.2-2.3zM6.343 8.494h-5.7c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h5.7c.2 0 .3.2.3.3s-.1.3-.3.3zM6.343 12.394h-5.7c-.2 0-.3-.2-.3-.3 0-.2.2-.3.3-.3h5.7c.2 0 .3.2.3.3.1.1-.1.3-.3.3zM6.343 16.194h-2.5c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h2.5c.2 0 .3.2.3.3s-.1.3-.3.3z"></path></g></switch></svg>
        
Tamil</span>

</div>
     
<div class="uk-card uk-align-center uk-width-1-1@s uk-width-1-2@l uk-width-1-2@m span11" >
    <span>The meme god of our class, creative head, techno freak and what not..
         Sreejith has been it all! With his child like mysterious sly smile and well 
         timed sarcastic comebacks you know that something is always cooking up in the 
         back of his head even when he is just chilling (with a beer mug in hand obviously 😋). 
         Hereby wishing you all the best Shalini! You have signed up with the right guy! He will
          surely keep you on your toes 🤣.. A lifetime of entertainment indeed!! 🎉<br/>&nbsp;&nbsp;
        
        <svg style={{width:"2%",height:"3%",color:"#ef1372"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"><switch><g><path d="M16.143 18.594h-.1c-6.6-2.5-7.4-5.9-7.4-8.6 0-2.5 1.8-4.5 3.9-4.5 1.5 0 2.9.8 3.6 2.1.7-1.3 2.1-2.1 3.6-2.1 2.2 0 3.9 2 3.9 4.5 0 2.7-.8 6.1-7.4 8.6h-.1zm-3.5-12.5s-.1 0 0 0c-1.8 0-3.3 1.7-3.3 3.8 0 2.4.8 5.6 6.8 7.9 6.1-2.4 6.8-5.5 6.8-7.9 0-2.1-1.5-3.8-3.2-3.8-1.5 0-2.9 1-3.3 2.4 0 .1-.2.2-.3.2-.2 0-.3-.1-.3-.3-.4-1.3-1.7-2.3-3.2-2.3zM6.343 8.494h-5.7c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h5.7c.2 0 .3.2.3.3s-.1.3-.3.3zM6.343 12.394h-5.7c-.2 0-.3-.2-.3-.3 0-.2.2-.3.3-.3h5.7c.2 0 .3.2.3.3.1.1-.1.3-.3.3zM6.343 16.194h-2.5c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h2.5c.2 0 .3.2.3.3s-.1.3-.3.3z"></path></g></switch></svg>
        -Suyashi (Suyuuuuu)</span></div>

<div class="uk-card uk-align-center uk-width-1-1@s uk-width-1-2@l uk-width-1-2@m span11" >
    <span>Congratulations on your wedding buddy! May the love you have for each
         other continue to grow and blossom with each passing year. May your marriage 
         be blessed with love, joy, and companionship for all the years of your life.<br/>&nbsp;&nbsp;
        
        <svg style={{width:"2%",height:"3%",color:"#ef1372"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"><switch><g><path d="M16.143 18.594h-.1c-6.6-2.5-7.4-5.9-7.4-8.6 0-2.5 1.8-4.5 3.9-4.5 1.5 0 2.9.8 3.6 2.1.7-1.3 2.1-2.1 3.6-2.1 2.2 0 3.9 2 3.9 4.5 0 2.7-.8 6.1-7.4 8.6h-.1zm-3.5-12.5s-.1 0 0 0c-1.8 0-3.3 1.7-3.3 3.8 0 2.4.8 5.6 6.8 7.9 6.1-2.4 6.8-5.5 6.8-7.9 0-2.1-1.5-3.8-3.2-3.8-1.5 0-2.9 1-3.3 2.4 0 .1-.2.2-.3.2-.2 0-.3-.1-.3-.3-.4-1.3-1.7-2.3-3.2-2.3zM6.343 8.494h-5.7c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h5.7c.2 0 .3.2.3.3s-.1.3-.3.3zM6.343 12.394h-5.7c-.2 0-.3-.2-.3-.3 0-.2.2-.3.3-.3h5.7c.2 0 .3.2.3.3.1.1-.1.3-.3.3zM6.343 16.194h-2.5c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h2.5c.2 0 .3.2.3.3s-.1.3-.3.3z"></path></g></switch></svg>
        
Smrithi Prasad</span>
</div>

<div class="uk-card uk-align-center uk-width-1-1@s uk-width-1-2@l uk-width-1-2@m span12" >
    <span>Heartiest congratulations Guys!!! Nothing can be a better way to celebrate a
         decade of togetherness than a promise to be each other’s forever. Even though
          the times are challenging, your love for each other has overcome it all. Hope
           the new chapters of your life be full of colors blended by this master of photoshop 
           and creatively splashed with happiness like his ever-wandering mind. Am sure his good 
           sense of humor will always keep that smile on your face intact. All the more his genuine
            heart will always be blessed by the eternal love you both have. Cheers to your special day
             and All the best for the new adventures to come!<br/>&nbsp;&nbsp;
        
        <svg style={{width:"2%",height:"3%",color:"#ef1372"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"><switch><g><path d="M16.143 18.594h-.1c-6.6-2.5-7.4-5.9-7.4-8.6 0-2.5 1.8-4.5 3.9-4.5 1.5 0 2.9.8 3.6 2.1.7-1.3 2.1-2.1 3.6-2.1 2.2 0 3.9 2 3.9 4.5 0 2.7-.8 6.1-7.4 8.6h-.1zm-3.5-12.5s-.1 0 0 0c-1.8 0-3.3 1.7-3.3 3.8 0 2.4.8 5.6 6.8 7.9 6.1-2.4 6.8-5.5 6.8-7.9 0-2.1-1.5-3.8-3.2-3.8-1.5 0-2.9 1-3.3 2.4 0 .1-.2.2-.3.2-.2 0-.3-.1-.3-.3-.4-1.3-1.7-2.3-3.2-2.3zM6.343 8.494h-5.7c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h5.7c.2 0 .3.2.3.3s-.1.3-.3.3zM6.343 12.394h-5.7c-.2 0-.3-.2-.3-.3 0-.2.2-.3.3-.3h5.7c.2 0 .3.2.3.3.1.1-.1.3-.3.3zM6.343 16.194h-2.5c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h2.5c.2 0 .3.2.3.3s-.1.3-.3.3z"></path></g></switch></svg>
        
Vismaya</span>

</div>

<div class="uk-card uk-align-center uk-width-1-1@s uk-width-1-2@l uk-width-1-2@m span11" >
    <span>My dearest Shalini & Sreejith, Oh my. The day has finally come. To the world;
         these two exceptional people are my friends. Shalini, a mirror image of my mind 
         (almost) is one of my closets friends. We go back, almost a decade. I have listened
          to the all the “firsts” till the “I am getting married, Aishu”. I cannot express how 
          happy I am to know you both are going to be together for life. All the best to Sreejith
           though :P. Kidding. He must be very lucky to have my Shalini. I cannot find two more
            people who are better for each other. Stay happy always. All my love to you two, of course a
             tad bit more to my Shalini. I love you both. Take care of each other & have a lovely lovely
              wedding day!<br/>&nbsp;&nbsp;
        
        <svg style={{width:"2%",height:"3%",color:"#ef1372"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"><switch><g><path d="M16.143 18.594h-.1c-6.6-2.5-7.4-5.9-7.4-8.6 0-2.5 1.8-4.5 3.9-4.5 1.5 0 2.9.8 3.6 2.1.7-1.3 2.1-2.1 3.6-2.1 2.2 0 3.9 2 3.9 4.5 0 2.7-.8 6.1-7.4 8.6h-.1zm-3.5-12.5s-.1 0 0 0c-1.8 0-3.3 1.7-3.3 3.8 0 2.4.8 5.6 6.8 7.9 6.1-2.4 6.8-5.5 6.8-7.9 0-2.1-1.5-3.8-3.2-3.8-1.5 0-2.9 1-3.3 2.4 0 .1-.2.2-.3.2-.2 0-.3-.1-.3-.3-.4-1.3-1.7-2.3-3.2-2.3zM6.343 8.494h-5.7c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h5.7c.2 0 .3.2.3.3s-.1.3-.3.3zM6.343 12.394h-5.7c-.2 0-.3-.2-.3-.3 0-.2.2-.3.3-.3h5.7c.2 0 .3.2.3.3.1.1-.1.3-.3.3zM6.343 16.194h-2.5c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h2.5c.2 0 .3.2.3.3s-.1.3-.3.3z"></path></g></switch></svg>
        
Your Aishu :)</span>

</div>

<div class="uk-card uk-align-center uk-width-1-1@s uk-width-1-2@l uk-width-1-2@m span11" >
    <span>Macha Sreejith uu iniya kalyana valthukal!! Marrying someone who you love is 
        some of the highest feat of accomplishment in these time and I'm super happy you 
        are gonna be an official member of that achievement.....i'm super jealous too but I'm 
        hoping your bachelors party would make me feel better. I wish you and Shalini both an 
        amazing and fun married life. (P. S. Kalyanathiku apparo engla marandhiradey da.......adhichu 
        nyabago paduthuve paathiko👍🏼)<br/>&nbsp;&nbsp;
        
        <svg style={{width:"2%",height:"3%",color:"#ef1372"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"><switch><g><path d="M16.143 18.594h-.1c-6.6-2.5-7.4-5.9-7.4-8.6 0-2.5 1.8-4.5 3.9-4.5 1.5 0 2.9.8 3.6 2.1.7-1.3 2.1-2.1 3.6-2.1 2.2 0 3.9 2 3.9 4.5 0 2.7-.8 6.1-7.4 8.6h-.1zm-3.5-12.5s-.1 0 0 0c-1.8 0-3.3 1.7-3.3 3.8 0 2.4.8 5.6 6.8 7.9 6.1-2.4 6.8-5.5 6.8-7.9 0-2.1-1.5-3.8-3.2-3.8-1.5 0-2.9 1-3.3 2.4 0 .1-.2.2-.3.2-.2 0-.3-.1-.3-.3-.4-1.3-1.7-2.3-3.2-2.3zM6.343 8.494h-5.7c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h5.7c.2 0 .3.2.3.3s-.1.3-.3.3zM6.343 12.394h-5.7c-.2 0-.3-.2-.3-.3 0-.2.2-.3.3-.3h5.7c.2 0 .3.2.3.3.1.1-.1.3-.3.3zM6.343 16.194h-2.5c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h2.5c.2 0 .3.2.3.3s-.1.3-.3.3z"></path></g></switch></svg>
        
Yours K Gokul Kalaimathi</span>
</div>

<div class="uk-card uk-align-center uk-width-1-1@s uk-width-1-2@l uk-width-1-2@m span12" >
    <span>Not many people get to marry their childhood sweetheart.. You both are one such couple who 
        are lucky for finding their lobsters so early in life ( F.R.I.E.N.D.S.) This beautiful wedding
         after years and years of your relationship shows us that there is indeed a 'happily ever after' 
         in every story.. it makes me wanna believe more in love, trust and togetherness that you both portray..!!
          Touch wood..!! Wishing you both a happy married life and lifetime full of love and happiness !!<br/>&nbsp;&nbsp;
        
        <svg style={{width:"2%",height:"3%",color:"#ef1372"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"><switch><g><path d="M16.143 18.594h-.1c-6.6-2.5-7.4-5.9-7.4-8.6 0-2.5 1.8-4.5 3.9-4.5 1.5 0 2.9.8 3.6 2.1.7-1.3 2.1-2.1 3.6-2.1 2.2 0 3.9 2 3.9 4.5 0 2.7-.8 6.1-7.4 8.6h-.1zm-3.5-12.5s-.1 0 0 0c-1.8 0-3.3 1.7-3.3 3.8 0 2.4.8 5.6 6.8 7.9 6.1-2.4 6.8-5.5 6.8-7.9 0-2.1-1.5-3.8-3.2-3.8-1.5 0-2.9 1-3.3 2.4 0 .1-.2.2-.3.2-.2 0-.3-.1-.3-.3-.4-1.3-1.7-2.3-3.2-2.3zM6.343 8.494h-5.7c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h5.7c.2 0 .3.2.3.3s-.1.3-.3.3zM6.343 12.394h-5.7c-.2 0-.3-.2-.3-.3 0-.2.2-.3.3-.3h5.7c.2 0 .3.2.3.3.1.1-.1.3-.3.3zM6.343 16.194h-2.5c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h2.5c.2 0 .3.2.3.3s-.1.3-.3.3z"></path></g></switch></svg>
        
- Niveditha Paulraj</span>
</div>


<div class="uk-card uk-align-center uk-width-1-1@s uk-width-1-2@l uk-width-1-2@m span11" >
    <span>Sreejith!! I need our tanker memories rather than just stories! Hoping that 
        we meet and celebrate this soon 🎉. Wishing you all the best for entering a new chapter 
        of life. Stay blessed and take care you both!<br/> &nbsp;&nbsp;
        
<svg style={{width:"2%",height:"3%",color:"#ef1372"}} viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1"><switch><g><path d="M16.143 18.594h-.1c-6.6-2.5-7.4-5.9-7.4-8.6 0-2.5 1.8-4.5 3.9-4.5 1.5 0 2.9.8 3.6 2.1.7-1.3 2.1-2.1 3.6-2.1 2.2 0 3.9 2 3.9 4.5 0 2.7-.8 6.1-7.4 8.6h-.1zm-3.5-12.5s-.1 0 0 0c-1.8 0-3.3 1.7-3.3 3.8 0 2.4.8 5.6 6.8 7.9 6.1-2.4 6.8-5.5 6.8-7.9 0-2.1-1.5-3.8-3.2-3.8-1.5 0-2.9 1-3.3 2.4 0 .1-.2.2-.3.2-.2 0-.3-.1-.3-.3-.4-1.3-1.7-2.3-3.2-2.3zM6.343 8.494h-5.7c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h5.7c.2 0 .3.2.3.3s-.1.3-.3.3zM6.343 12.394h-5.7c-.2 0-.3-.2-.3-.3 0-.2.2-.3.3-.3h5.7c.2 0 .3.2.3.3.1.1-.1.3-.3.3zM6.343 16.194h-2.5c-.2 0-.3-.2-.3-.3s.2-.3.3-.3h2.5c.2 0 .3.2.3.3s-.1.3-.3.3z"></path></g></switch></svg>

Utkarsh (Ut)</span>
</div>




<div class="btn21 uk-visible@s uk-visible@m" >
<a href="/" >
<button class="uk-button uk-button-default   btn2" style={{color:"#ef1372",borderColor:"#ef1372",borderRadius:"20px",textTransform:"initial",marginLeft:"10%"}} href="#">Back to invite</button>
</a>
   <a href="/sendwish" >
<button  class="uk-button uk-button-default   btn1" style={{backgroundColor:"#ef1372",color:"white",borderRadius:"20px",textTransform:"initial",marginLeft:"10%"}} href="#">Send Your Wishes</button>
</a>
</div>


<div class="btn212 uk-hidden@s uk-hidden@m" >
<a href="/" >
<button class="uk-button uk-button-default   btn22" style={{color:"#ef1372",borderColor:"#ef1372",borderRadius:"20px",textTransform:"initial",width:"46%",height:"10%"}} href="#">Back to invite</button>
</a>
<a href="/sendwish" >
<button  class="uk-button uk-button-default   btn11" style={{backgroundColor:"#ef1372",color:"white",borderRadius:"20px",textTransform:"initial",width:"52%",height:"8%"}} href="#">Send Your Wishes</button>
</a>
  
</div>
</div>


<div class="uk-card uk-card-body imgg11 uk-visible@s" >
<span class="imgg41" >EVENTS SHOT BY</span><br/>
    <img class="imgg21 " src={img3}></img> 
    <img class="uk-align-right imgg31" src={img4}></img>
   <span class="uk-align-right imgg51">POWERD BY</span>
    
</div>

<div class="uk-card uk-card-body  imgg11 uk-hidden@s" >
<span class="imgg411 uk-align-center" >EVENTS SHOT BY
<img class="imgg211 uk-align-center" src={img3}></img></span> <br/>
<span class=" uk-align-center imgg311">POWERD BY <img class="imgg511 " src={img4}></img></span>
</div>

        </div>
        );
    }
     export default Wish;