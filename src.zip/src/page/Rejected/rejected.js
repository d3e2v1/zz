import React from 'react'
import { Link } from 'react-router-dom';
import './rejected.css'


function Rejected()
{
    return(
        <div>

<a class=" " href="/Nav" uk-icon="icon: arrow-left; ratio: 2"></a>
<div class=" uk-align-center h121" >
    <p>Happily Bonded Shalini & Sreejith</p>
    <p class="h12">Hidden Photos</p>
</div>
<form><div class="uk-margin h131">
        <input class="uk-input uk-form-width-large " type="text" placeholder="Enter PIN to view hidden photos"/>
</div></form>






</div>
        );
    }
     export default Rejected;
